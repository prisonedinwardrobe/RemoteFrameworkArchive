//Created by leonid on 01.07.2021

#import <Foundation/Foundation.h>

//! Project version number for RemoteFramework.
FOUNDATION_EXPORT double RemoteFrameworkVersionNumber;

//! Project version string for RemoteFramework.
FOUNDATION_EXPORT const unsigned char RemoteFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteFramework/PublicHeader.h>


